import http from "../http-common"; 

const saveUserDetails = (data) => {
  return http.post("/user-management", data);
};
 

const UserManagementService = {
  saveUserDetails, 
};

export default UserManagementService;
