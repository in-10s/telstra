import React from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "@fortawesome/fontawesome-free/css/all.css";
import "@fortawesome/fontawesome-free/js/all.js";
import "./App.css"; 
import UserManagement from "./components/user-management/user-management";
import KendoChart from "./components/kendo/KendoChart";
function App() {
  return (
    <div>
      <nav className="navbar navbar-expand navbar-dark bg-dark"> 
        <div className="navbar-nav mr-auto">
          <li className="nav-item">
            <Link to={"/user-management"} className="nav-link">
              User Management
            </Link>
          </li> 
          <li className="nav-item">
            <Link to={"/my-app"} className="nav-link">
              Kendo Chart
            </Link>
          </li>
        </div>
      </nav>

      <div className="container mt-3">
        <Switch> 
          <Route exact path="/user-management" component={UserManagement} />
          <Route exact path="/my-appt" component={KendoChart} /> 
            
        </Switch>
      </div>
    </div>
  );
}

export default App;
