/* eslint-disable no-undef */
import React, { useState } from "react"; 
import UserManagementService from "../../services/UserManagementService.js"; 
const Login = () => {
  const initialUserState = {
    loginName:'',
    password:'' 
  };
  const [user, setUser] = useState(initialUserState);
  const [submitted, setSubmitted] = useState(false);

  const handleInputChange = event => {
    const { name, value } = event.target;
    setUser({ ...user, [name]: value });
  }; 
  const login = () => {
    var data = {
        username:user.loginName,
        password:user.password
    };
    UserManagementService.login(data)
      .then(response => { 
        alert(response.data.token) 
        if(response.data.token!==undefined){ 
          window.location.href='/user-management'
        }
        alert("loggedin successfully") 
      })
      .catch(e => {
        alert("Sorry, Invalid credential")       
        console.log(e);
      });  
  };

  const save = () => {
    setUser(initialUserState);
    setSubmitted(false);
  };

  return (
    <div className="submit-form">
      {submitted ? (
        <div>
          <h4>You submitted successfully!</h4>
          <button className="btn btn-success" onClick={save}>
            Add
          </button>
        </div>
      ) : (
        <div>
          <div className="form-group">
            <label htmlFor="title">Username</label>
            <input
              type="text"
              className="form-control"
              id="loginName"
              required
              value={user.loginName}
              onChange={handleInputChange}
              name="loginName"
            />
          </div>

          <div className="form-group">
            <label htmlFor="description">Password</label>
            <input
              type="password"
              className="form-control"
              id="password"
              required
              value={user.password}
              onChange={handleInputChange}
              name="password"
            />
          </div> 
          <button onClick={login} className="btn btn-success">
            Submit
          </button>
        </div>
      )}
    </div>
  );
};

export default Login;
