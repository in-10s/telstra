import React, { useState } from "react";
import UserManagementService from "../../services/UserManagementService"; 

const UserManagement = () => {
  const initialUserState = {
    loginName:'',
    password:'',
    firstName:'', 
    lastName:"" ,
    secondName:'', 
    department:"" ,
    emailID:'', 
    phoneNumber:'', 
    role:'', 
    landingPage:'', 
    moduleName:''
  };
  const [user, setUser] = useState(initialUserState);
  const [submitted, setSubmitted] = useState(false);

  const handleInputChange = event => {
    const { name, value } = event.target;
    setUser({ ...user, [name]: value });
  };

  const saveUser = () => {
    var data = {
        loginName:user.loginName,
        password:user.password,
        firstName:user.firstName, 
        lastName:user.lastName,
        secondName:user.secondName, 
        department:user.department ,
        emailID:user.emailID, 
        phoneNumber:user.phoneNumber, 
        role:user.role, 
        landingPage:user.landingPage, 
        moduleName:user.moduleName
    };

    UserManagementService.saveUserDetails(data)
      .then(response => {
        setUser({ 
          loginName:response.data.loginName,
          password:response.data.password,
          firstName:response.data.firstName, 
          lastName:response.data.lastName ,
          secondName:response.data.secondName, 
          department:response.data.department ,
          emailID:response.data.emailID, 
          phoneNumber:response.data.phoneNumber, 
          role:response.data.role, 
          landingPage:response.data.landingPage, 
          moduleName:response.data.moduleName
        });
        setSubmitted(true);
        alert("saved successfully")
        console.log(response.data);
      })
      .catch(e => {
        alert("saved successfully")
        console.log(e);
      });
  };

  const save = () => {
    setUser(initialUserState);
    setSubmitted(false);
  };

  return (
    <div className="submit-form">
      {submitted ? (
        <div>
          <h4>You submitted successfully!</h4>
          <button className="btn btn-success" onClick={save}>
            Add
          </button>
        </div>
      ) : (
        <div>
          <div className="form-group">
            <label htmlFor="title">Login Name</label>
            <input
              type="text"
              className="form-control"
              id="loginName"
              required
              value={user.loginName}
              onChange={handleInputChange}
              name="loginName"
            />
          </div>

          <div className="form-group">
            <label htmlFor="description">Password</label>
            <input
              type="text"
              className="form-control"
              id="password"
              required
              value={user.password}
              onChange={handleInputChange}
              name="password"
            />
          </div>
          <div className="form-group">
            <label htmlFor="firstName">First Name</label>
            <input
              type="text"
              className="form-control"
              id="firstName"
              required
              value={user.firstName}
              onChange={handleInputChange}
              name="firstName"
            />
          </div><div className="form-group">
            <label htmlFor="title">Middle Name</label>
            <input
              type="text"
              className="form-control"
              id="secondName"
              required
              value={user.secondName}
              onChange={handleInputChange}
              name="secondName"
            />
          </div><div className="form-group">
            <label htmlFor="title">Last name</label>
            <input
              type="text"
              className="form-control"
              id="lastName"
              required
              value={user.lastName}
              onChange={handleInputChange}
              name="lastName"
            />
          </div><div className="form-group">
            <label htmlFor="emailID">Email ID</label>
            <input
              type="text"
              className="form-control"
              id="emailID"
              required
              value={user.emailID}
              onChange={handleInputChange}
              name="emailID"
            />
          </div><div className="form-group">
            <label htmlFor="phoneNumber">PhoneNumber</label>
            <input
              type="text"
              className="form-control"
              id="phoneNumber"
              required
              value={user.phoneNumber}
              onChange={handleInputChange}
              name="phoneNumber"
            />
          </div>
          <div className="form-group">
            <label htmlFor="title">Role </label>
            <select class="input-bordered"  name="role"  id="role" value={user.role} onChange={handleInputChange} >
                <option>Select Role</option> 
                <option>Role I</option>
             </select> 
          </div>
          <div className="form-group">
          <label htmlFor="title">Landing Page </label>
            <select class="input-bordered"  name="landingPage"  id="landingPage" value={user.landingPage} onChange={handleInputChange} >
                <option>Select Landing Page</option> 
                <option>Landing Page I</option>
             </select>  
          </div>
          <div className="form-group">
          <label htmlFor="title">Module Name</label>
            <select class="input-bordered"  name="moduleName"  id="moduleName" value={user.moduleName} onChange={handleInputChange} >
                <option>Select Module Name</option> 
                <option>Module Name I</option>
             </select>  
          </div>
          <div className="form-group">
          <label htmlFor="title">Department</label>
            <select class="input-bordered"  name="department"  id="department" value={user.department} onChange={handleInputChange} >
                <option>Select Department</option> 
                <option>Department I</option>
             </select>  
          </div>
          <button onClick={saveUser} className="btn btn-success">
            Submit
          </button>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
