import React from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "@fortawesome/fontawesome-free/css/all.css";
import "@fortawesome/fontawesome-free/js/all.js";
import "./App.css"; 
import UserManagement from "./components/user-management/user-management";
import KendoChart from "./components/kendo/KendoChart";
import Login from "./components/login/login"; 
function App() {
  return (
    <div>
      <nav className="navbar navbar-expand navbar-dark bg-dark"> 
        <div className="navbar-nav mr-auto">
          <li className="nav-item" style={window.location.href!=="/user-management" ?  {}:{ display: 'none' }}> 
            <Link to={"/login"} className="nav-link">
             Login
            </Link>
          </li>  
          <li className="nav-item" style={window.location.href!=="/login" ? {}:{ display: 'none' }}>
            <Link to={"/user-management"} className="nav-link">
              User Management
            </Link>
          </li> 
          <li className="nav-item" style={window.location.href!=="/login" ? {}:{ display: 'none' }}>
            <Link to={"/my-app"} className="nav-link">
              Kendo Chart
            </Link>
          </li>
        </div>
      </nav>

      <div className="container mt-3">
        <Switch> 
          <Route exact path="/user-management" component={UserManagement} />
          <Route exact path="/my-app" component={KendoChart} /> 
          <Route exact path="/login" component={Login} /> 
        </Switch>
      </div>
    </div>
  );
}

export default App;
