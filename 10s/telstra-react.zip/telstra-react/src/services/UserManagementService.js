/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable react/jsx-no-undef */
import http from "../http-common";  
 
const saveUserDetails = (data) => {
  return http.post("/user-management", data);
};

const login = (data) => { 
  return http.post("http://localhost:7676/authenticate",data);
};

const hasLogged = (isLoggedIn) =>{
  return isLoggedIn;
}
const getLoginStatus = () =>{
  return hasLogged
}
const UserManagementService = {
  saveUserDetails, 
  login,
  hasLogged,
  getLoginStatus
};

export default UserManagementService;
